# deprecated, but old tests use "from hstest.stage_test import StageTest"
# new way to import is "from hstest import StageTest"
from hstest.stage.stage_test import *
