from hstest.exception.outcomes import TestPassed, WrongAnswer

# deprecated, but have to be sure old tests work as expected
TestPassedException = TestPassed
WrongAnswerException = WrongAnswer
