
class Settings:

    do_reset_output: bool = True
    allow_out_of_input: bool = False

    def __init__(self):
        raise NotImplementedError('Instances of the class Settings are prohibited')
